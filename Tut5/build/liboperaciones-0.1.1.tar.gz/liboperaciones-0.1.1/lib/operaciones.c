#include <math.h>

float add(float a, float b) { 
  return a + b;
}

float sub(float a, float b) {
  return a - b;
}

float mul(float a, float b) {
  return a * b;
}

float div(float a, float b) {
  return a / b;
}

float square_root(float a) {
  return sqrt(a);
}
